﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SnakeGame_Gary
{
    internal class Program
    {
        private static Player PlayerOne = new Player()
        {
            Direction = new Vector2(1, 0),
            InputDirections = new Dictionary<ConsoleKey, Vector2>()
            {
                {
                    ConsoleKey.W, Vector2.Up
                },
                {
                    ConsoleKey.S, Vector2.Down
                },
                {
                    ConsoleKey.A, Vector2.Left
                },
                {
                    ConsoleKey.D, Vector2.Right
                },
            }
        };
        private static Player PlayerTwo = new Player()
        {
            Direction = new Vector2(1, 0),
            InputDirections = new Dictionary<ConsoleKey, Vector2>()
            {
                {
                    ConsoleKey.UpArrow, Vector2.Up
                },
                {
                    ConsoleKey.DownArrow, Vector2.Down
                },
                {
                    ConsoleKey.LeftArrow, Vector2.Left
                },
                {
                    ConsoleKey.RightArrow, Vector2.Right
                },
            }
        };
        public const int TimeScale = 100;
        private static bool[,] usedGridPositions;
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WindowHeight = 30;
                Console.BufferHeight = 30;
                Console.WindowWidth = 100;
                Console.BufferWidth = 100;
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.White;
                var title = "Write a number to define time gap (ms)";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 0);
                Console.WriteLine($"{title}");
                int TimeScale;
                Console.SetCursorPosition(Console.BufferWidth / 2, 1);
                if (int.TryParse(Console.ReadLine(), out TimeScale))
                {

                }
                else
                {
                    Console.WriteLine("Write a number to define time gap (ms)");
                    continue;
                }
                PlayerOne.Score = 0;
                PlayerTwo.Score = 0;
                while (true)
                {
                    Console.Clear();
                    #region StartScreen
                    usedGridPositions = new bool[Console.WindowWidth, Console.WindowHeight];
                    title = "Snakes Strike";
                    Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 0);
                    Console.WriteLine($"{title}");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"Player One's Controls:\n\n" +
                                      $"W - Up\n" +
                                      $"A - Left\n" +
                                      $"S - Down\n" +
                                      $"D - Right\n");
                    title = "Player Two's Controls:";
                    Console.SetCursorPosition(Console.BufferWidth - title.Length, 1);
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"{title}");
                    Console.SetCursorPosition(Console.BufferWidth - title.Length, 3);
                    Console.WriteLine($"Up - Up");
                    Console.SetCursorPosition(Console.BufferWidth - title.Length, 4);
                    Console.WriteLine($"Left - Left");
                    Console.SetCursorPosition(Console.BufferWidth - title.Length, 5);
                    Console.WriteLine($"Down - Down");
                    Console.SetCursorPosition(Console.BufferWidth - title.Length, 6);
                    Console.WriteLine($"Right - Right");

                    title = "Press any key to start";
                    Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 7);
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine($"{title}");
                    Console.ReadKey();
                    Console.Clear();
                    #endregion
                    #region Initialization
                    PlayerOne.Direction = Vector2.Right;
                    PlayerOne.Position.x = 0;
                    PlayerOne.Position.y = Console.WindowHeight / 2;
                    PlayerTwo.Direction = Vector2.Left;
                    PlayerTwo.Position.x = Console.WindowWidth - 1;
                    PlayerTwo.Position.y = Console.WindowHeight / 2;
                    for (int i = 0; i < Console.WindowWidth; i++)
                    {
                        for (int j = 0; j < Console.WindowHeight; j++)
                        {
                            usedGridPositions[i, j] = false;
                        }
                    }
                    #endregion
                    while (true)
                    {
                        if (Console.KeyAvailable)
                        {
                            var key = Console.ReadKey(true);
                            if (key.Key == ConsoleKey.W && (PlayerOne.Direction != Vector2.Down))
                            {
                                PlayerOne.Direction = Vector2.Up;
                            }
                            if (key.Key == ConsoleKey.A && (PlayerOne.Direction != Vector2.Right))
                            {
                                PlayerOne.Direction = Vector2.Left;
                            }
                            if (key.Key == ConsoleKey.S && (PlayerOne.Direction != Vector2.Up))
                            {
                                PlayerOne.Direction = Vector2.Down;
                            }
                            if (key.Key == ConsoleKey.D && (PlayerOne.Direction != Vector2.Left))
                            {
                                PlayerOne.Direction = Vector2.Right;
                            }
                            if (key.Key == ConsoleKey.UpArrow && (PlayerTwo.Direction != Vector2.Down))
                            {
                                PlayerTwo.Direction = Vector2.Up;
                            }
                            if (key.Key == ConsoleKey.LeftArrow && (PlayerTwo.Direction != Vector2.Right))
                            {
                                PlayerTwo.Direction = Vector2.Left;
                            }
                            if (key.Key == ConsoleKey.DownArrow && (PlayerTwo.Direction != Vector2.Up))
                            {
                                PlayerTwo.Direction = Vector2.Down;
                            }
                            if (key.Key == ConsoleKey.RightArrow && (PlayerTwo.Direction != Vector2.Left))
                            {
                                PlayerTwo.Direction = Vector2.Right;
                            }
                        }
                        bool P1hit = false;
                        bool P2hit = false;
                        DrawPlayer(PlayerOne.Position.x, PlayerOne.Position.y, '*', ConsoleColor.Yellow);
                        DrawPlayer(PlayerTwo.Position.x, PlayerTwo.Position.y, '*', ConsoleColor.Cyan);
                        usedGridPositions[PlayerOne.Position.x, PlayerOne.Position.y] = true;
                        usedGridPositions[PlayerTwo.Position.x, PlayerTwo.Position.y] = true;
                        PlayerOne.Position += PlayerOne.Direction;
                        PlayerTwo.Position += PlayerTwo.Direction;
                        if ((PlayerOne.Position.x < 0) || (PlayerOne.Position.x > Console.WindowWidth - 1) || (PlayerOne.Position.y < 0) || (PlayerOne.Position.y > Console.WindowHeight - 1))
                        {
                            P1hit = true;
                        }
                        else if (usedGridPositions[PlayerOne.Position.x, PlayerOne.Position.y] == true)
                        {
                            P1hit = true;
                        }
                        if ((PlayerTwo.Position.x < 0) || (PlayerTwo.Position.x > Console.WindowWidth - 1) || (PlayerTwo.Position.y < 0) || (PlayerTwo.Position.y > Console.WindowHeight - 1))
                        {
                            P2hit = true;
                        }
                        else if (usedGridPositions[PlayerTwo.Position.x, PlayerTwo.Position.y] == true)
                        {
                            P2hit = true;
                        }
                        if ((P1hit == true) && (P2hit != true))
                        {
                            PlayerTwo.Score++;
                        }
                        if ((P1hit != true) && (P2hit == true))
                        {
                            PlayerOne.Score++;
                        }
                        if ((P1hit == true) || (P2hit == true))
                        {
                            Console.ForegroundColor = ConsoleColor.White;
                            var titleScore = "Player One : Player Two";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 1);
                            Console.Write($"{titleScore}");
                            titleScore = $"{PlayerOne.Score} : {PlayerTwo.Score}";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 2);
                            Console.WriteLine($"{titleScore}");
                            titleScore = "Press any key to continue";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 3);
                            Console.WriteLine($"{titleScore}");
                            break;
                        }
                        Thread.Sleep(TimeScale);
                    }
                    if (PlayerOne.Score == 3)
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.White;
                        var titleScore = "Player One : Player Two";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 1);
                        Console.Write($"{titleScore}");
                        titleScore = $"{PlayerOne.Score} : {PlayerTwo.Score}";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 2);
                        Console.WriteLine($"{titleScore}");
                        Console.ForegroundColor = ConsoleColor.Green;
                        titleScore = "Player One Wins!";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 3);
                        Console.WriteLine($"{titleScore}");
                        titleScore = "Press any key to restart the game";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 4);
                        Console.WriteLine($"{titleScore}");
                        Console.ReadKey();
                        break;
                    }
                    if (PlayerTwo.Score == 3)
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.White;
                        var titleScore = "Player One : Player Two";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 1);
                        Console.Write($"{titleScore}");
                        titleScore = $"{PlayerOne.Score} : {PlayerTwo.Score}";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 2);
                        Console.WriteLine($"{titleScore}");
                        Console.ForegroundColor = ConsoleColor.Green;
                        titleScore = "Player Two Wins!";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 3);
                        Console.WriteLine($"{titleScore}");
                        titleScore = "Press any key to restart the game";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - titleScore.Length / 2, 4);
                        Console.WriteLine($"{titleScore}");
                        Console.ReadKey();
                        break;
                    }
                    Console.ReadKey();
                }
            }
        }
        private static void DrawPlayer(int positionX, int positionY, char PlayerSymbol, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.SetCursorPosition(positionX, positionY);
            Console.Write(PlayerSymbol);
        }
        public struct Vector2
        {
            public int x;
            public int y;

            public Vector2(int _x,int _y)
            {
                this.x = _x;
                this.y = _y;
            }

            public static readonly Vector2 Up = new Vector2(0, -1);
            public static readonly Vector2 Down = new Vector2(0, 1);
            public static readonly Vector2 Left= new Vector2(-1, 0);
            public static readonly Vector2 Right = new Vector2(1, 0);

            public static Vector2 operator +(Vector2 v1, Vector2 v2)
            {
                return new Vector2(v1.x + v2.x, v1.y + v2.y);
            }

            public static Vector2 operator -(Vector2 v)
            {
                return new Vector2(-v.x, -v.y);
            }

            public static bool operator ==(Vector2 v1, Vector2 v2)
            {
                return (v1.x == v2.x && v1.y == v2.y);
            }

            public static bool operator !=(Vector2 v1, Vector2 v2)
            {
                return ((v1.x != v2.x) || (v1.y != v2.y));
            }

        }
        public class Player
        {

            public Vector2 Direction;
            public Vector2 Position;
            public int Score = 0;

            public Dictionary<ConsoleKey, Vector2> InputDirections;

        }
    }
}