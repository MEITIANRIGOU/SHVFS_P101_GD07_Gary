﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hangman_Gary
{
    class Program
    {
        static void Main(string[] args)
        {
            #region WordsList

            string[] Words = new string[26];
            Words[0] = "alphabet";
            Words[1] = "brain";
            Words[2] = "chosen";
            Words[3] = "doom";
            Words[4] = "elf";
            Words[5] = "fake";
            Words[6] = "game";
            Words[7] = "hostile";
            Words[8] = "impossible";
            Words[9] = "joker";
            Words[10] = "killer";
            Words[11] = "linux";
            Words[12] = "milestone";
            Words[13] = "necromancer";
            Words[14] = "olympic";
            Words[15] = "protoss";
            Words[16] = "queen";
            Words[17] = "ring";
            Words[18] = "soul";
            Words[19] = "torment";
            Words[20] = "unix";
            Words[21] = "vampire";
            Words[22] = "world";
            Words[23] = "xenophobia";
            Words[24] = "yoyo";
            Words[25] = "zombie";

            #endregion

            while (true)
            {
                string TheWord;
                bool[] CorrectOrNot;
                int Wrong = 0;

                Console.Clear();
                Console.ForegroundColor = ConsoleColor.White;

                Console.SetCursorPosition(0, 10);
                Console.WriteLine($"     |=======+");
                Console.WriteLine($"     |       +");
                Console.WriteLine($"     |       O");
                Console.WriteLine($"     |      /|\\");
                Console.WriteLine($"     |       |");
                Console.WriteLine($"     |      / \\");
                Console.WriteLine($"     |");
                Console.WriteLine($"     |");

                var title = "Hangman";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 0);
                Console.Write($"{title}");

                title = "Enter a word to guess, or press Enter to start with a random word";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 1);
                Console.WriteLine($"{title}");

                title = "(Only 26 random words for now XD)";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 2);
                Console.WriteLine($"{title}");

                title = "Only lowercase English is supported";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 3);
                Console.WriteLine($"{title}");

                Console.SetCursorPosition(Console.BufferWidth / 2, 5);
                TheWord = Console.ReadLine();
                Console.SetCursorPosition(Console.BufferWidth / 2, 6);

                bool Detect = false;

                if (TheWord == "")
                {
                    Random rd = new Random();
                    int i = rd.Next(0, 26);
                    TheWord = Words[i];
                }

                for (int i = 0; i < TheWord.Length; i++)
                {
                    if ((TheWord[i] >= ' ' && TheWord[i] <= '`') || (TheWord[i] >= '{' && TheWord[i] <= '~'))
                    {
                        Detect = true;
                        break;
                    }
                }

                if (Detect == false)
                {
                    CorrectOrNot = new bool[TheWord.Length];

                    for (int i = 0; i < TheWord.Length; i++)
                    {
                        CorrectOrNot[i] = false;
                    }

                    for (int i = 0; i < TheWord.Length; i++)
                    {
                        if (CorrectOrNot[i] == true)
                        {
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"{TheWord[i]}");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"_");
                        }
                    }
                }
                else
                {
                    title = "Only lowercase English is supported";
                    Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 3);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"{title}");

                    title = "Press Enter to restart";
                    Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 7);
                    Console.Write($"{title}");

                    Console.ReadLine();
                    continue;
                }

                Console.Clear();

                while (true)
                {
                    #region CorrectDetect

                    Console.SetCursorPosition(0, 4);
                    for (int i = 0; i < 100; i++)
                    {
                        Console.Write($" ");
                    }

                    Console.SetCursorPosition(0, 5);
                    for (int i = 0; i < 100; i++)
                    {
                        Console.Write($" ");
                    }


                    bool CorrectDetect = true;

                    for (int i = 0; i < TheWord.Length; i++)
                    {
                        if (CorrectOrNot[i] == false)
                        {
                            CorrectDetect = false;
                        }
                    }

                    if (CorrectDetect == true)
                    {
                        Console.Clear();

                        title = "Hangman";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 0);
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write($"{title}");

                        title = "Congratulation!";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 1);
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"{title}");

                        title = "Press Enter to start a new game";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 2);
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine($"{title}");

                        Console.ReadLine();
                        break;
                    }

                    #endregion

                    #region GameScreen

                    Console.ForegroundColor = ConsoleColor.White;

                    title = "Hangman";
                    Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 0);
                    Console.Write($"{title}");

                    title = "Enter a character to guess";
                    Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 1);
                    Console.WriteLine($"{title}");

                    title = "Only lowercase English is supported";
                    Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 2);
                    Console.WriteLine($"{title}");

                    Console.SetCursorPosition(Console.BufferWidth / 2, 3);

                    for (int i = 0; i < TheWord.Length; i++)
                    {
                        if (CorrectOrNot[i] == true)
                        {
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"{TheWord[i]}");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"_");
                        }
                    }

                    #endregion

                    bool TotallyWrongOrNot = true;

                    char Character;

                    while (Wrong < 7)
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.SetCursorPosition(0, 4);
                        for (int i = 0; i < 100; i++)
                        {
                            Console.Write($" ");
                        }
                        Console.SetCursorPosition(Console.BufferWidth / 2, 4);
                        Character = (char)Console.Read();
                        if (Char.IsLetter(Character))
                        {
                            if (Char.IsLower(Character))
                            {
                                for (int i = 0; i < TheWord.Length; i++)
                                {
                                    if (TheWord[i] == Character)
                                    {
                                        if (CorrectOrNot[i] == false)
                                        {
                                            CorrectOrNot[i] = true;
                                            Console.SetCursorPosition(Console.BufferWidth / 2 + i, 3);
                                            Console.ForegroundColor = ConsoleColor.White;
                                            Console.Write($"{TheWord[i]}");
                                            TotallyWrongOrNot = false;
                                            Console.SetCursorPosition(Console.BufferWidth / 2, 5);
                                            Console.ForegroundColor = ConsoleColor.Green;
                                            Console.Write($"You are right, press Enter to continue");
                                            Console.ReadLine();
                                        }
                                    }
                                }
                                if (TotallyWrongOrNot == true)
                                {
                                    Wrong++;
                                    WrongPaint(Wrong);
                                    Console.SetCursorPosition(Console.BufferWidth / 2, 5);
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.Write($"You are wrong, press Enter to continue");
                                    Console.ReadLine();
                                }
                            }
                            else
                            {
                                title = "Only lowercase English is supported";
                                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 2);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine($"{title}");
                                Console.ReadLine();
                                break;
                            }
                        }
                        else
                        {
                            title = "Not a character!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 5);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($"{title}");
                            Console.ReadLine();
                            break;
                        }
                    }

                    if (Wrong == 7)
                    {
                        Console.Clear();

                        Console.SetCursorPosition(0, 10);
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine($"     |=======+");
                        Console.WriteLine($"     |       +");
                        Console.WriteLine($"     |       O");
                        Console.WriteLine($"     |      /|\\");
                        Console.WriteLine($"     |       |");
                        Console.WriteLine($"     |      / \\");
                        Console.WriteLine($"     |");
                        Console.WriteLine($"     |");

                        Console.ForegroundColor = ConsoleColor.White;

                        title = "Hangman";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 0);
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write($"{title}");

                        title = "You failed!";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 1);
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"{title}");

                        title = "Press Enter to start a new game";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 2);
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine($"{title}");

                        Console.ReadLine();

                        break;
                    }
                }
            }
        }

        public static void WrongPaint(int Number)
        {

            int WrongNumber = Number;
            switch (WrongNumber)
            {
                case 1:
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"     |=======+");
                    Console.WriteLine($"     |       +");
                    Console.WriteLine($"     |       O");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    break;

                case 2:
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"     |=======+");
                    Console.WriteLine($"     |       +");
                    Console.WriteLine($"     |       O");
                    Console.WriteLine($"     |       |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    break;

                case 3:
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"     |=======+");
                    Console.WriteLine($"     |       +");
                    Console.WriteLine($"     |       O");
                    Console.WriteLine($"     |      /|");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    break;

                case 4:
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"     |=======+");
                    Console.WriteLine($"     |       +");
                    Console.WriteLine($"     |       O");
                    Console.WriteLine($"     |      /|\\");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    break;

                case 5:
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"     |=======+");
                    Console.WriteLine($"     |       +");
                    Console.WriteLine($"     |       O");
                    Console.WriteLine($"     |      /|\\");
                    Console.WriteLine($"     |       |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    break;

                case 6:
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"     |=======+");
                    Console.WriteLine($"     |       +");
                    Console.WriteLine($"     |       O");
                    Console.WriteLine($"     |      /|\\");
                    Console.WriteLine($"     |       |");
                    Console.WriteLine($"     |      /");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    break;

                case 7:
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.WriteLine($"                    ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.SetCursorPosition(0, 10);
                    Console.WriteLine($"     |=======+");
                    Console.WriteLine($"     |       +");
                    Console.WriteLine($"     |       O");
                    Console.WriteLine($"     |      /|\\");
                    Console.WriteLine($"     |       |");
                    Console.WriteLine($"     |      / \\");
                    Console.WriteLine($"     |");
                    Console.WriteLine($"     |");
                    break;
            }
        }
    }
}