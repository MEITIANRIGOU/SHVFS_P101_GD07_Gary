﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SHVFS_GD07_P101_Gary
{
    class Program
    {
        static void Main(string[] args)
        {
            int answer = 80;
            int guess = 0;

            while(guess != answer)
            {
                Console.WriteLine($"GUESS A NUMBER.\n");

                guess = Convert.ToInt32(Console.ReadLine());

                if (guess == answer)
                {
                    Console.WriteLine($"YOU ARE RIGHT!\n");
                }
                else if (guess > answer)
                {
                    Console.WriteLine($"TOO BIG!\n");
                }
                else if (guess < answer)
                {
                    Console.WriteLine($"TOO SMALL!\n");
                }
            }

            Console.ReadLine();
            //christopher.T.riley@gmail.com
        }
    }
}
