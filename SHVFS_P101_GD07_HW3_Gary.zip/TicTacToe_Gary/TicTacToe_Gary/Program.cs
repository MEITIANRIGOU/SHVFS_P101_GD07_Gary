﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe_Gary
{
    class Program
    {
        private static int[] board;
        static void Main(string[] args)
        {
            while (true)
            {
                #region StartScreen
                Console.Clear();
                Console.WindowHeight = 20;
                Console.BufferHeight = 20;
                Console.WindowWidth = 100;
                Console.BufferWidth = 100;
                board = new int[9];
                var title = "Tic Tac Toe";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 0);
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"{title}");
                Console.ForegroundColor = ConsoleColor.Yellow;
                title = "Player One is X";
                Console.SetCursorPosition(10, 2);
                Console.Write($"{title}");
                title = "Player Two is O";
                Console.SetCursorPosition(Console.BufferWidth - title.Length - 10, 2);
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write($"{title}");
                Console.ForegroundColor = ConsoleColor.White;
                title = "Press 1 - 9 for the position of the board";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 4);
                Console.Write($"{title}");
                title = "Press any key to start";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 5);
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"{title}");
                Console.ReadKey();
                Console.Clear();
                #endregion
                #region Initialization
                for (int i = 0; i < 9; i++)
                {
                    board[i] = 0;
                }
                title = "000";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 3);
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"{title}");
                title = "000";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 4);
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"{title}");
                title = "000";
                Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 5);
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"{title}");
                #endregion
                for (int i = 0;i < 9;i++)
                {
                    if ((i % 2) == 0 )
                    {
                        title = "Player One's turn";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 0);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write($"{title}");
                        title = "Press 1-9 and enter to confirm";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 1);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write($"{title}");
                        Console.SetCursorPosition(Console.BufferWidth / 2, 2);
                        int key = 0;
                        if (int.TryParse(Console.ReadLine(), out key))
                        {
                            
                        }
                        else
                        {
                            title = "Press 1-9!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 8);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "You break the rule!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 9);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "Player Two Wins!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 10);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.Write($"{title}");
                            title = "Press any key to restart the game";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 11);
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"{title}");
                            Console.ReadKey();
                            break;
                        }
                        if (key > 9 || key < 0)
                        {
                            title = "Press 1-9!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 8);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "You break the rule!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 9);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "Player Two Wins!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 10);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.Write($"{title}");
                            title = "Press any key to restart the game";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 11);
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"{title}");
                            Console.ReadKey();
                            break;
                        }
                        if (board[key - 1] != 0)
                        {
                            title = "Don't play on an occupied position!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 8);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "You break the rule!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 9);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "Player Two Wins!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 10);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.Write($"{title}");
                            title = "Press any key to restart the game";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 11);
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"{title}");
                            Console.ReadKey();
                            break;
                        }
                        else
                        {
                            board[key - 1] = 1;
                            title = "X";
                            Console.SetCursorPosition((Console.BufferWidth / 2 - title.Length / 2) - 1 + (key-1)%3, ((key-1)/3)+3);
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.Write($"{title}");
                        }
                        if ((board[0]==1) && (board[1] == 1) && (board[2] == 1))
                        {
                            PlayerOneWins();
                            break;
                        }
                        if ((board[3] == 1) && (board[4] == 1) && (board[5] == 1))
                        {
                            PlayerOneWins();
                            break;
                        }
                        if ((board[6] == 1) && (board[7] == 1) && (board[8] == 1))
                        {
                            PlayerOneWins();
                            break;
                        }
                        if ((board[0] == 1) && (board[3] == 1) && (board[6] == 1))
                        {
                            PlayerOneWins();
                            break;
                        }
                        if ((board[1] == 1) && (board[4] == 1) && (board[7] == 1))
                        {
                            PlayerOneWins();
                            break;
                        }
                        if ((board[2] == 1) && (board[5] == 1) && (board[8] == 1))
                        {
                            PlayerOneWins();
                            break;
                        }
                        if ((board[0] == 1) && (board[4] == 1) && (board[8] == 1))
                        {
                            PlayerOneWins();
                            break;
                        }
                        if ((board[2] == 1) && (board[4] == 1) && (board[6] == 1))
                        {
                            PlayerOneWins();
                            break;
                        }
                    }
                    else
                    {
                        title = "Player Two's turn";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 0);
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write($"{title}");
                        title = "Press 1-9 and enter to confirm";
                        Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 1);
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write($"{title}");
                        Console.SetCursorPosition(Console.BufferWidth / 2, 2);
                        int key = 0;
                        if (int.TryParse(Console.ReadLine(), out key))
                        {

                        }
                        else
                        {
                            title = "Press 1-9!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 8);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "You break the rule!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 9);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "Player One Wins!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 10);
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.Write($"{title}");
                            title = "Press any key to restart the game";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 11);
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"{title}");
                            Console.ReadKey();
                            break;
                        }
                        if (key > 9 || key < 0)
                        {
                            title = "Press 1-9!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 8);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "You break the rule!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 9);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "Player One Wins!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 10);
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.Write($"{title}");
                            title = "Press any key to restart the game";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 11);
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"{title}");
                            Console.ReadKey();
                            break;
                        }
                            if (board[key - 1] != 0)
                        {
                            title = "Don't play on an occupied position!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 8);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "You break the rule!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 9);
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write($"{title}");
                            title = "Player One Wins!";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 10);
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.Write($"{title}");
                            title = "Press any key to restart the game";
                            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 11);
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Write($"{title}");
                            Console.ReadKey();
                            break;
                        }
                        else
                        {
                            board[key - 1] = 2;
                            title = "O";
                            Console.SetCursorPosition((Console.BufferWidth / 2 - title.Length / 2) - 1 + (key - 1) % 3, ((key - 1) / 3) + 3);
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.Write($"{title}");
                        }
                        if ((board[0] == 2) && (board[1] == 2) && (board[2] == 2))
                        {
                            PlayerTwoWins();
                            break;
                        }
                        if ((board[3] == 2) && (board[4] == 2) && (board[5] == 2))
                        {
                            PlayerTwoWins();
                            break;
                        }
                        if ((board[6] == 2) && (board[7] == 2) && (board[8] == 2))
                        {
                            PlayerTwoWins();
                            break;
                        }
                        if ((board[0] == 2) && (board[3] == 2) && (board[6] == 2))
                        {
                            PlayerTwoWins();
                            break;
                        }
                        if ((board[1] == 2) && (board[4] == 2) && (board[7] == 2))
                        {
                            PlayerTwoWins();
                            break;
                        }
                        if ((board[2] == 2) && (board[5] == 2) && (board[8] == 2))
                        {
                            PlayerTwoWins();
                            break;
                        }
                        if ((board[0] == 2) && (board[4] == 2) && (board[8] == 2))
                        {
                            PlayerTwoWins();
                            break;
                        }
                        if ((board[2] == 2) && (board[4] == 2) && (board[6] == 2))
                        {
                            PlayerTwoWins();
                            break;
                        }
                    }
                    if (i == 8)
                    {
                        Draw();
                    }
                }
            }
        }
        private static void PlayerOneWins()
        {
            var title = "Player One Wins!";
            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 8);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"{title}");
            title = "Press any key to restart";
            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 9);
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($"{title}");
            Console.ReadKey();
        }
        private static void PlayerTwoWins()
        {
            var title = "Player Two Wins!";
            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 8);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write($"{title}");
            title = "Press any key to restart";
            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 9);
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($"{title}");
            Console.ReadKey();
        }
        private static void Draw()
        {
            var title = "Draw!";
            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 8);
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($"{title}");
            title = "Press any key to restart";
            Console.SetCursorPosition(Console.BufferWidth / 2 - title.Length / 2, 9);
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($"{title}");
            Console.ReadKey();
        }
    }
}